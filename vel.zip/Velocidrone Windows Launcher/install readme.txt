Please follow the Installation video: https://youtu.be/KJmw98Px5F4

For controller setup: https://youtu.be/EcpFA1wOVP0

If you have a problematic controller that needs an axis by axis setup or the above process does not work for you: https://youtu.be/tiqfw9Fhhpk

If velocidrone cannot see your controller (most common reason on windows):  https://batcavegames.freshdesk.com/a/solutions/articles/16000099501
Other common reasons are using a charging rather than data usb cable, using a faulty usb cable or not having the controller in joystick mode for usb connection.

For any issues most of the common problems are documented in our knowledge base: https://batcavegames.freshdesk.com/a/solutions

If you need to contact support: https://batcavegames.freshdesk.com/support/tickets/new

For help by a very active community and the only group that velocidrone developers access and reply to daily: https://www.facebook.com/groups/velocidronesim/
